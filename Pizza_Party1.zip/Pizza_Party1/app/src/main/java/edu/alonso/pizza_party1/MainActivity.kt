package edu.alonso.pizza_party1

/**
 * Andy Alonso | COP 2600 | 5/24/25 | Delgado
 */

import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.view.View

// const val SLICES_PER_PIZZA = 8 //constant number of pizza pie slices
const val TAG = "MainActivity" // Creates a tag for MainActivity @ logcat


class MainActivity : AppCompatActivity() {

    private lateinit var numAttendEditText: EditText      // Number of People...Including User
    private lateinit var numPizzasTextView: TextView      // Display number of people in display
    private lateinit var howHungryRadioGroup: RadioGroup  // How hungry are the people

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)                // Super Class
        setContentView(R.layout.activity_main)            // goes with res/layout/activity_main.xml
        numAttendEditText = findViewById(R.id.num_attend_edit_text) // Initializing the numAttendEditText by finding the view with the XML ID num_attend_edit_text
        numPizzasTextView = findViewById(R.id.num_pizzas_text_view) // Initializing the numPizzasTextView by finding the view with the XML ID num_pizzas_text_view
        howHungryRadioGroup = findViewById(R.id.hungry_radio_group) // Initializing the howHungryRadioGroup by finding the view with the XML ID hungry_radio_group

        Log.d(TAG, "onCreate was called")            // log for onCreate that it was called @ logcat → mainActivity
    }

    fun calculateClick(view: View) {

        val numAttendStr = numAttendEditText.text.toString()  // Gets the number that was typed to String...Also Called TypeCasting

        Log.d(TAG, "calculateClick was called $numAttendStr") // log for calculateClick that the number was called to $numAttendStr

        val numAttend = numAttendStr.toIntOrNull() ?: 0 // String → Int or NULL = 0
        val hungerLevel = when (howHungryRadioGroup.checkedRadioButtonId) { // Average Slice per person
            R.id.light_radio_button -> PizzaCalculator.HungerLevel.LIGHT // If Light was selected its 2
            R.id.medium_radio_button -> PizzaCalculator.HungerLevel.MEDIUM // if Medium was selected its 3
            else -> PizzaCalculator.HungerLevel.RAVENOUS // "Large" or Ravenous is 4 slices CAUSE THEYRE HUNGRY
        }
        // Get the Number of Pizzas Needed
        val calc = PizzaCalculator(numAttend, hungerLevel)
        val totalPizzas = calc.totalPizzas

        //this will display the calculated number of pizzas needed
        val totalText = getString(R.string.total_pizzas, totalPizzas)
        numPizzasTextView.text = totalText


    }

}