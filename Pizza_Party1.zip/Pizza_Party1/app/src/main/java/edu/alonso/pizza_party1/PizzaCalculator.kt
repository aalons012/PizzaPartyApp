package edu.alonso.pizza_party1

/**
 * Andy Alonso | COP 2600 | 5/24/25 | Delgado
 */

import kotlin.math.ceil

const val SLICES_PER_PIZZA = 8

class PizzaCalculator (partySize: Int, var hungerLevel: HungerLevel) {
    var partySize = 0
        set(value) {
            field = if (value >= 0) value else 0
        }

    enum class HungerLevel(var numSlices: Int) {
        LIGHT(2), MEDIUM(3), RAVENOUS(4)
    }

    val totalPizzas: Int
        get() { // Getter for total Pizzas
                // Calculate the total number of pizzas from the num of people TIMES the Hunger Lv DIVIDED by the slices per pizza
                // which will TYPECAST to double first and then to Int
            return ceil(partySize * hungerLevel.numSlices / SLICES_PER_PIZZA.toDouble()).toInt()
        }

    init {
        this.partySize = partySize
    }
}